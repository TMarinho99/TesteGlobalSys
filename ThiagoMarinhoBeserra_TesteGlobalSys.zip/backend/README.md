Passo a Passo.

1 - Execute no terminal
    . yarn (instalar as dependencias)

2 - Alterar as variáveis ambiente
    . Altere no arquivo .env para
    configurar o Banco

3 - Execute no terminal
    . yarn dev (para iniciar a API)